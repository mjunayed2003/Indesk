import { Navigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import { getAccessibleNavItems } from '../config/navigation';

interface SmartRedirectProps {
    preferredRoutes?: string[];
    fallbackPath?: string;
}

export function SmartRedirect({ 
    preferredRoutes, 
    fallbackPath = '/no-access' 
}: SmartRedirectProps) {
    const { user } = useSelector((state: RootState) => state.auth);
    const location = useLocation();
    const effectiveFallback = user ? fallbackPath : '/login';
    
    // Get all accessible routes
    const accessibleRoutes = getAccessibleNavItems(user);

    // Determine the best route to redirect to
    const redirectPath = getBestRoute(accessibleRoutes, preferredRoutes, effectiveFallback);

    if (redirectPath === location.pathname) {
        return null;
    }

    return <Navigate to={redirectPath} replace />;
}

// Helper function to find the best route
function getBestRoute(
    accessibleRoutes: any[], 
    preferredRoutes?: string[], 
    fallbackPath = '/login'
): string {
    if (accessibleRoutes.length === 0) {
        return fallbackPath;
    }

    // 1. Check preferred routes first
    if (preferredRoutes && preferredRoutes.length > 0) {
        for (const preferredPath of preferredRoutes) {
            const preferredRoute = accessibleRoutes.find(route => route.path === preferredPath);
            if (preferredRoute) {
                return preferredRoute.path;
            }
        }
    }

    // 2. Try to find a dashboard
    const dashboardRoute = accessibleRoutes.find(route => 
        route.path.includes('dashboard') || route.path === '/'
    );

    if (dashboardRoute) {
        return dashboardRoute.path;
    }

    // 3. Return the first accessible route
    return accessibleRoutes[0].path;
}
