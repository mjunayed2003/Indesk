import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import type { RootState } from "../../store";

interface LoginCredentials {
  email: string;
  password: string;
}

interface AuthTokens {
  access: {
    token: string;
    expiresAt: string;
  };
  refresh: {
    token: string;
    expiresAt: string;
  };
}

interface AuthenticatedUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  avatar: string;
  isEmailVerified: boolean;
  fcmToken: string | null;
  phoneNumber: string | null;
  countryCode: string | null;
  isRestricted: boolean;
  restrictionReason: string | null;
  bio: string | null;
  isOnline: boolean;
  lastSeen: string | null;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
  subscription?: {
    id: string;
    clinicId: string;
    planId: string;
    status: string;
    stripeCustomerId: string | null;
    stripeSubscriptionId: string | null;
    currentPeriodStart: string | null;
    currentPeriodEnd: string | null;
    trialStart: string | null;
    trialEnd: string | null;
    cancelledAt: string | null;
    createdAt: string;
    updatedAt: string;
    plan?: {
      id: string;
      name: string;
      type: string;
      description?: string | null;
      price: number;
    };
  } | null;
}

interface LoginResponse {
  success: boolean;
  status: number;
  message: string;
  response: {
    data: AuthenticatedUser;
    tokens: AuthTokens;
  };
}

interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: "user";
}

interface RegisterResponse {
  success: boolean;
  status: number;
  message: string;
  response: {
    data: Record<string, never>;
  };
}

interface VerifyAccountRequest {
  email: string;
  code: string;
}

interface ForgotPasswordRequest {
  email: string;
}

interface ForgotPasswordResponse {
  success: boolean;
  status: number;
  message: string;
  response?: {
    data?: Record<string, unknown>;
  };
}

interface ResetPasswordRequest {
  email: string;
  otp: string;
  password: string;
}

interface ResetPasswordResponse {
  success: boolean;
  status: number;
  message: string;
  response?: {
    data?: Record<string, unknown>;
  };
}

interface VerifyAccountResponse {
  success: boolean;
  status: number;
  message: string;
  response: {
    data: AuthenticatedUser & {
      permissions?: Record<string, boolean>;
      lastPasswordChangedAt?: string | null;
    };
    tokens: AuthTokens;
  };
}

interface LogoutRequest {
  refreshToken: string;
}

interface LogoutResponse {
  success: boolean;
  status: number;
  message: string;
}

interface ChangePasswordRequest {
  oldPassword: string;
  newPassword: string;
}

interface ChangePasswordResponse {
  success: boolean;
  status: number;
  message: string;
}

interface UpdateSelfProfileRequest {
  firstName: string;
  lastName: string;
  avatar?: File | null;
}

interface SelfClinicMembership {
  id: string;
  role: string;
  clinicianToken: string | null;
  availability: string[];
  specialization: string[];
}

interface SelfOwnedClinic {
  id: string;
  name: string;
  email: string;
  logo: string | null;
  color: string | null;
  isActive: boolean;
}

interface SelfUserData {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  avatar: string | null;
  isEmailVerified: boolean;
  phoneNumber: string | null;
  countryCode: string | null;
  bio: string | null;
  isOnline: boolean;
  lastSeen: string | null;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
  permissions?: Record<string, boolean>;
  clinicMemberships?: SelfClinicMembership[];
  ownedClinics?: SelfOwnedClinic[];
}

interface GetSelfProfileResponse {
  success: boolean;
  status: number;
  message: string;
  response: {
    data: SelfUserData;
  };
}

interface UpdateSelfProfileResponse {
  success: boolean;
  status: number;
  message: string;
  response?: {
    data?: SelfUserData;
  };
}

export const authApi = createApi({
  reducerPath: "authApi",
  baseQuery: fetchBaseQuery({
    baseUrl: import.meta.env.VITE_API_BASE_URL,
    prepareHeaders: (headers, { getState }) => {
      const skipContentType = headers.get("x-skip-content-type") === "true";
      if (skipContentType) {
        headers.delete("x-skip-content-type");
      } else {
        headers.set("Content-Type", "application/json");
      }

      const state = getState() as RootState;
      const expiresAt = state.auth.tokens?.access?.expiresAt;
      const isReduxTokenValid = expiresAt
        ? new Date(expiresAt) > new Date()
        : true;
      let token = isReduxTokenValid ? state.auth.tokens?.access?.token : null;

      if (!token) {
        const localExpiry = localStorage.getItem("accessTokenExpiry");
        const isLocalValid = localExpiry
          ? new Date(localExpiry) > new Date()
          : false;
        token = isLocalValid ? localStorage.getItem("accessToken") : null;
      }

      if (token) {
        headers.set("Authorization", `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: (builder) => ({
    login: builder.mutation<LoginResponse, LoginCredentials>({
      query: (credentials) => ({
        url: "/auth/login",
        method: "POST",
        body: credentials,
      }),
    }),
    register: builder.mutation<RegisterResponse, RegisterRequest>({
      query: (body) => ({
        url: "/auth/register",
        method: "POST",
        body,
      }),
    }),
    verifyAccount: builder.mutation<
      VerifyAccountResponse,
      VerifyAccountRequest
    >({
      query: (body) => ({
        url: "/auth/verify-account",
        method: "POST",
        body,
      }),
    }),
    forgotPassword: builder.mutation<
      ForgotPasswordResponse,
      ForgotPasswordRequest
    >({
      query: (body) => ({
        url: "/auth/forgot-password",
        method: "POST",
        body,
      }),
    }),
    resetPassword: builder.mutation<
      ResetPasswordResponse,
      ResetPasswordRequest
    >({
      query: (body) => ({
        url: "/auth/reset-password",
        method: "POST",
        body,
      }),
    }),
    logout: builder.mutation<LogoutResponse, LogoutRequest>({
      query: (body) => ({
        url: "/auth/logout",
        method: "POST",
        body,
      }),
    }),
    changePassword: builder.mutation<
      ChangePasswordResponse,
      ChangePasswordRequest
    >({
      query: (body) => ({
        url: "/auth/change-password",
        method: "POST",
        body,
      }),
    }),
    updateSelfProfile: builder.mutation<
      UpdateSelfProfileResponse,
      UpdateSelfProfileRequest
    >({
      query: ({ firstName, lastName, avatar }) => {
        const formData = new FormData();
        formData.append("firstName", firstName);
        formData.append("lastName", lastName);
        if (avatar) {
          formData.append("avatar", avatar);
        }

        return {
          url: "/user/self/update",
          method: "PATCH",
          body: formData,
          headers: {
            "x-skip-content-type": "true",
          },
        };
      },
    }),
    getSelfProfile: builder.query<GetSelfProfileResponse, void>({
      query: () => ({
        url: "/user/self/in",
        method: "GET",
      }),
    }),
  }),
});

export const {
  useLoginMutation,
  useRegisterMutation,
  useVerifyAccountMutation,
  useForgotPasswordMutation,
  useResetPasswordMutation,
  useLogoutMutation,
  useGetSelfProfileQuery,
  useUpdateSelfProfileMutation,
  useChangePasswordMutation,
} = authApi;
